#include <stdio.h>
#include <stdlib.h>

#include "parse.h"
#include "array_counter.h"

//extern int m_count;
//extern int m_size;
//char* token;

int m_mode = 0; // start outside class
int parse ( char* filename );
int parse_slash ( int index, int file_end, FILE *fp );


int token_check( );

int filesize( FILE *fp );


int main ( int argc, char *argv[] ) {

	initialize_parse();
	parse ( argv[1] );

	//token_check ();

	return 0;
}

int token_check( ) {

	token[0] = 'a';

	printf("%d\n", token[0]);

	return 0;
}

int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

int parse ( char* filename ) {

	FILE *fp;
	fp = fopen ( filename, "rb" );
	char dummy[1];

	int file_end = filesize ( fp );

	for( int i=0; i<file_end; i++ ) {

		fread ( dummy, 1, 1, fp);

		switch( dummy[0] ) {
		case ' ':
			analyze ( token ) ;
			break;
		case '/':
			parse_slash( i, file_end, fp);
			break;
		}

		token = put_token ( dummy[0] );
//		printf( "%d %d\n", *token, token);
		printf ("dummy=%s token=%s token[%d]=%d token[%d]=%d\n", dummy, token, i, token[i], i + 1, token[ i + 1] );
	}

	printf("token=%s\n", token);

	for( int i=0; i<file_end; i++ ) {

		switch( dummy[0] ) {
		case ' ':
			break;
		case '/':
			parse_slash( i, file_end, fp);
			break;
		}

		printf( "%d\n", token[i] );
	}

	fclose(fp);

	return 0;
}

int analyze ( char* tkn ) {

	m_mode = 0;
	
	switch(m_mode) {
	case 0:
		// keyword outside class
		
		break;
	case 1:
		// name outside class
		break;
	case 2:
		break;
	}

	return 0;
}




int parse_slash ( int index, int file_end, FILE *fp ) {

	char dummy[1];

	for( int i=index; i<file_end; i++ ) {

		fread ( dummy, 1, 1, fp);
	}

	return 0;
}



