

extern int array_count( char *ary );
