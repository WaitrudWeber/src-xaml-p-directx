

extern int m_a;

