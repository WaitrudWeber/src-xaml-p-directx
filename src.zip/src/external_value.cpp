#include <stdio.h>
#include <stdlib.h>
#include "external_value.h"

int m_a = 0;


