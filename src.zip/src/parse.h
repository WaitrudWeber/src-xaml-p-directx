extern char* string_allocation (int size) ;
extern char* put_token (char c);

extern char* string_allocation (int size) ;
extern int initialize_parse ();


extern int m_coun;
extern int m_size;
extern char* token;


