#pragma once
#ifndef GRANDPARENT_H
#define GRANDPARENT_H

namespace App7
{

	extern 	float m_add_X = 0.1f;
	//float m_add_X = 0.1f;
}

#endif /* !GRANDPARENT_H */
